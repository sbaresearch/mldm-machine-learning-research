# https://www.edureka.co/blog/bayesian-networks/
import itertools
import math
import random
from typing import Dict

import numpy
from pomegranate import DiscreteDistribution, ConditionalProbabilityTable, State, BayesianNetwork



def generateRandomProbabilityDist(randVarAmount: int):
    dist = []

    for i in range(int(math.pow(randVarAmount, randVarAmount))):
        dist.append(float(random.randint(0, 1000)) / 1000)

    return dist


def generateConditionalProbabilityTable(randVarAmount: int, propDist: [int]):
    # generate list of random vars

    # with n^n lines
    x = [chr(x) for x in range(65, 65 + randVarAmount)]
    perms = [list(p) + [d] for p, d in zip(itertools.product(x, repeat=randVarAmount), propDist)]

    return perms


def generateDiscreteDitributions(distrAmount):

    distrDict = {}
    distributions = []

    for i in range(65, 65+distrAmount):
        distrDict[chr(i)] = 1/distrAmount

    for i in range(distrAmount-1):
        distributions.append(DiscreteDistribution(distrDict))


    return distributions


def buildNetwork(stateAmount: int, conProp: ConditionalProbabilityTable, discProps: [DiscreteDistribution], connections: [[int]]):

    states = []

    for i in range(stateAmount-1):
        states.append(State(discProps[i]))

    states.append(conProp)

    network = BayesianNetwork("")
    for state in states:
        network.add_state(state)

    # pass definition on how the states are connected
    # like [[0,2],[1,2]] for monty hall
    # 0 guest
    # 1 prize
    # 2 monty

    d1 = State(states[0], name="guest")
    d2 = State(states[1], name="prize")
    d3 = State(states[2], name="monty")

    # Building the Bayesian Network
    network = BayesianNetwork("Solving the Monty Hall Problem With Bayesian Networks")
    network.add_states(d1, d2, d3)
    network.add_edge(d1, d3)
    network.add_edge(d2, d3)
    network.bake()

    #for connection in connections:
    #    network.add_edge(states[connection[0]], states[connection[1]])

    #network.bake()
    return network

def constructNetwork(randAmount: int):
    guest = DiscreteDistribution({'A': 1. / 3, 'B': 1. / 3, 'C': 1. / 3})

    # The door containing the prize is also a random process
    prize = DiscreteDistribution({'A': 1. / 3, 'B': 1. / 3, 'C': 1. / 3})

    distr = generateRandomProbabilityDist(randAmount)

    table = generateConditionalProbabilityTable(randAmount, distr)
    distributions = generateDiscreteDitributions(3)
    monty = ConditionalProbabilityTable(table, distributions)

    # Building the Bayesian Network
    network = buildNetwork(randAmount, monty, distributions, [[0,2],[1,2]])

    # testing with two parameters
    beliefs = network.predict_proba({'guest': 'A', 'monty': 'B'})
    beliefParams: Dict = beliefs[1].parameters[0]

    return list(beliefParams.values()), distr


def compareWithTarget(a, b, rtol=0.1):
    return numpy.allclose(a, b, rtol=rtol, equal_nan=False)


if __name__ == "__main__":
    iterations: int = 0
    while True:
        iterations+=1
        probs, propDist = constructNetwork(3)
        if compareWithTarget(probs, [0.85, 0.15, 0.9], 0.9):
            print(f"found a solution in %d iterations", iterations)
            print(probs)
            print(propDist)
            break
        else:
            # todo optimize distribution with PSO
            pass
