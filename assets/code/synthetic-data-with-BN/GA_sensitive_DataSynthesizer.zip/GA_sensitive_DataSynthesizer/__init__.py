"""Top-level package for DataSynthesizer."""

__author__ = """Data, Responsibly"""
__email__ = 'dataresponsibly@gmail.com'
__version__ = '0.1.9'
