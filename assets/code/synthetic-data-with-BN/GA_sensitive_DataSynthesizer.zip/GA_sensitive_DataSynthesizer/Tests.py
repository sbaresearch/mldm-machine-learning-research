import unittest

from DataDescriber import DataDescriber
from DataGenerator import DataGenerator
from ModelInspector import ModelInspector
from lib.utils import read_json_file, display_bayesian_network

import pandas as pd

class MyTestCase(unittest.TestCase):

    def test_randomMode(self):
        input_data = '../notebooks/data/adult_ssn.csv'
        # location of two output files
        mode = 'random_mode'
        description_file = f'../notebooks/out/{mode}/description.json'
        synthetic_data = f'../notebooks/out/{mode}/sythetic_data.csv'

        # An attribute is categorical if its domain size is less than this threshold.
        # Here modify the threshold to adapt to the domain size of "education" (which is 14 in input dataset).
        threshold_value = 20

        # Number of tuples generated in synthetic dataset.
        num_tuples_to_generate = 32561  # Here 32561 is the same as input dataset, but it can be set to another number.

        describer = DataDescriber(category_threshold=threshold_value)
        describer.describe_dataset_in_random_mode(input_data)
        describer.save_dataset_description_to_file(description_file)

        generator = DataGenerator()
        generator.generate_dataset_in_random_mode(num_tuples_to_generate, description_file)
        generator.save_synthetic_data(synthetic_data)

        # Read both datasets using Pandas.
        input_df = pd.read_csv(input_data, skipinitialspace=True)
        synthetic_df = pd.read_csv(synthetic_data)
        # Read attribute description from the dataset description file.
        attribute_description = read_json_file(description_file)['attribute_description']

        inspector = ModelInspector(input_df, synthetic_df, attribute_description)

        for attribute in synthetic_df.columns:
            inspector.compare_histograms(attribute)

        pass

    def test_correlatedAttributeMode(self):
        input_data = '../notebooks/data/adult_ssn.csv'
        # location of two output files
        mode = 'random_mode' # todo change
        description_file = f'../notebooks/out/{mode}/description.json'
        synthetic_data = f'../notebooks/out/{mode}/sythetic_data.csv'

        # An attribute is categorical if its domain size is less than this threshold.
        # Here modify the threshold to adapt to the domain size of "education" (which is 14 in input dataset).
        threshold_value = 20

        # Number of tuples generated in synthetic dataset.
        num_tuples_to_generate = 32561  # Here 32561 is the same as input dataset, but it can be set to another number.

        describer = DataDescriber(category_threshold=threshold_value)
        describer.describe_dataset_in_correlated_attribute_mode(input_data)
        describer.save_dataset_description_to_file(description_file)

        generator = DataGenerator()
        generator.generate_dataset_in_random_mode(num_tuples_to_generate, description_file)
        generator.save_synthetic_data(synthetic_data)

        # Read both datasets using Pandas.
        input_df = pd.read_csv(input_data, skipinitialspace=True)
        synthetic_df = pd.read_csv(synthetic_data)
        # Read attribute description from the dataset description file.
        attribute_description = read_json_file(description_file)['attribute_description']

        inspector = ModelInspector(input_df, synthetic_df, attribute_description)

        for attribute in synthetic_df.columns:
            inspector.compare_histograms(attribute)

        pass


if __name__ == '__main__':
    unittest.main()
